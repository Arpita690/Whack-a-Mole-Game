import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class WhackAMoleGame {

    static JButton[] buttons = new JButton[9];

    static Random random = new Random();

    static int score = 0;
    static int molePosition = -1;
    static int timeLeft = 30;

    static JLabel scoreLabel;
    static JLabel timerLabel;

    static Timer moleTimer;
    static Timer gameTimer;

    public static void main(String[] args) {

        

        JFrame frame = new JFrame("Whack-a-Mole Game");

        frame.setSize(600, 500);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLocationRelativeTo(null);

        frame.setLayout(new BorderLayout());



        JPanel topPanel = new JPanel();

        scoreLabel = new JLabel("Score: 0");

        timerLabel = new JLabel("Time: 30 sec");

        scoreLabel.setFont(new Font("Arial", Font.BOLD, 18));

        timerLabel.setFont(new Font("Arial", Font.BOLD, 18));

        topPanel.add(scoreLabel);

        topPanel.add(Box.createHorizontalStrut(100));

        topPanel.add(timerLabel);



        JPanel gamePanel = new JPanel();

        gamePanel.setLayout(new GridLayout(3, 3, 10, 10));


        // Create 9 buttons

        for (int i = 0; i < 9; i++) {

            buttons[i] = new JButton();

            buttons[i].setFont(new Font("Arial", Font.BOLD, 20));

            final int buttonNumber = i;


 

            buttons[i].addActionListener(e -> {

                if (buttonNumber == molePosition) {

                    score++;

                    scoreLabel.setText("Score: " + score);

                 

                    buttons[molePosition].setText("");

                    molePosition = -1;
                }
            });


            gamePanel.add(buttons[i]);
        }


  

        JPanel bottomPanel = new JPanel();

        JButton restartButton = new JButton("Restart");

        restartButton.setFont(new Font("Arial", Font.BOLD, 16));

        bottomPanel.add(restartButton);


  

        frame.add(topPanel, BorderLayout.NORTH);

        frame.add(gamePanel, BorderLayout.CENTER);

        frame.add(bottomPanel, BorderLayout.SOUTH);


        frame.setVisible(true);


      

        moleTimer = new Timer(1000, e -> {

            // Remove previous mole

            for (JButton button : buttons) {

                button.setText("");
            }


         

            molePosition = random.nextInt(9);


    

            buttons[molePosition].setText("MOLE");
        });


     

        gameTimer = new Timer(1000, e -> {

            timeLeft--;

            timerLabel.setText("Time: " + timeLeft + " sec");


            // When time becomes 0

            if (timeLeft == 0) {

                // Stop timers

                gameTimer.stop();

                moleTimer.stop();


            

                for (JButton button : buttons) {

                    button.setText("");

                    button.setEnabled(false);
                }


                molePosition = -1;


           

                JOptionPane.showMessageDialog(
                        frame,
                        "Game Over!\nYour Score: " + score
                );
            }
        });


     

        moleTimer.start();

        gameTimer.start();




        restartButton.addActionListener(e -> {

         

            moleTimer.stop();

            gameTimer.stop();


            

            score = 0;

            timeLeft = 30;

            molePosition = -1;


            

            scoreLabel.setText("Score: 0");

            timerLabel.setText("Time: 30 sec");


      

            for (JButton button : buttons) {

                button.setEnabled(true);

                button.setText("");
            }


          

            moleTimer.start();

            gameTimer.start();
        });
    }
}